
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $max_ram = (int)$_POST['max_ram'];
    $max_storage = (int)$_POST['max_storage'];

    $users_file = 'users.json';
    $users = file_exists($users_file) ? json_decode(file_get_contents($users_file), true) : [];

    if (isset($users[$username])) {
        die('Username already exists. Please choose another.');
    }

    $users[$username] = [
        'password' => $password,
        'max_ram' => 0,
        'max_storage' => 0
    ];

    file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));

    // Create user directory
    $user_dir = __DIR__ . "/vps/$username";
    if (!is_dir($user_dir)) {
        mkdir($user_dir, 0777, true);
    }

    echo 'Registration successful! <a href="index.html">Login here</a>';
}
?>
