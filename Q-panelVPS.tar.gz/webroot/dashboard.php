<?php

session_start();

if (!isset($_SESSION['user'])) {

    header('Location: index.html');

    exit;

}

$username = $_SESSION['user'];

$vps_dir = __DIR__ . '/vps/' . $username;

// Functie om een VPS te verwijderen

function delete_vps($vps_name, $vps_dir) {

    $path = $vps_dir . '/' . $vps_name;

    if (is_dir($path)) {

        $files = array_diff(scandir($path), ['.', '..']);

        foreach ($files as $file) {

            unlink($path . '/' . $file);

        }

        rmdir($path);

    }

}

// Functie om bestanden in een VPS te tonen

function list_vps_files($vps_name, $vps_dir) {

    $path = $vps_dir . '/' . $vps_name;

    if (is_dir($path)) {

        $files = scandir($path);

        return array_filter($files, function ($file) {

            return $file !== '.' && $file !== '..';

        });

    }

    return [];

}

// Upload bestand

if (isset($_POST['upload']) && isset($_FILES['file']) && isset($_POST['vps_name'])) {

    $vps_name = $_POST['vps_name'];

    $target_dir = $vps_dir . '/' . $vps_name . '/';

    if (is_dir($target_dir)) {

        $target_file = $target_dir . basename($_FILES['file']['name']);

        move_uploaded_file($_FILES['file']['tmp_name'], $target_file);

    }

}

// Verwijder bestand

if (isset($_POST['delete_file']) && isset($_POST['vps_name']) && isset($_POST['file_name'])) {

    $vps_name = $_POST['vps_name'];

    $file_name = $_POST['file_name'];

    $file_path = $vps_dir . '/' . $vps_name . '/' . $file_name;

    if (is_file($file_path)) {

        unlink($file_path);

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>VPS Dashboard</title>

    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: #f8f9fa;

            color: #333;

            margin: 0;

            padding: 0;

        }

        header {

            background-color: #007bff;

            color: white;

            padding: 1em 0;

            text-align: center;

        }

        .container {

            margin: 20px auto;

            max-width: 800px;

            background: white;

            padding: 20px;

            border-radius: 8px;

            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);

        }

        .vps {

            margin-top: 20px;

        }

        .files, .ssh {

            display: none;

            margin-left: 20px;

            padding: 10px;

            border-radius: 4px;

        }

        .files {

            background: #f1f1f1;

        }

        .ssh {

            background: #333;

            color: #00ff00;

            padding: 10px;

            border-radius: 4px;

        }

        .ssh-output {

            background: #000;

            color: #00ff00;

            font-family: monospace;

            padding: 10px;

            height: 200px;

            overflow-y: auto;

            border-radius: 4px;

            margin-bottom: 10px;

        }

        .ssh-input {

            margin-top: 10px;

            display: flex;

        }

        .ssh-input input {

            flex: 1;

            padding: 10px;

            border: 1px solid #666;

            border-radius: 4px 0 0 4px;

            background: #444;

            color: #00ff00;

            font-family: monospace;

        }

        .ssh-input button {

            padding: 10px;

            border: none;

            border-radius: 0 4px 4px 0;

            background: #007bff;

            color: white;

            cursor: pointer;

        }

        .ssh-input button:hover {

            background: #0056b3;

        }

        .toggle {

            cursor: pointer;

            color: #007bff;

            margin: 5px 0;

            display: inline-block;

        }

        .delete-confirm {

            color: red;

            cursor: pointer;

        }

    </style>

    <script>

        function toggleSection(id) {

            const section = document.getElementById(id);

            section.style.display = section.style.display === 'block' ? 'none' : 'block';

        }

        function addSSHOutput(vpsId, command) {

            const outputDiv = document.getElementById('ssh-output-' + vpsId);

            const output = document.createElement('div');

            output.textContent = `user@${vpsId}:~$ ${command}`;

            outputDiv.appendChild(output);

            outputDiv.scrollTop = outputDiv.scrollHeight;

        }

        function confirmDeletion(vpsName) {

            if (confirm('Are you sure you want to delete VPS "' + vpsName + '"?')) {

                document.getElementById('delete-vps-form-' + vpsName).submit();

            }

        }

    </script>

</head>

<body>

    <header>

        <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>

    </header>

    <div class="container">

        <p>Manage your VPS instances and interact via the terminal.</p>

        <a href="create_vps.php">Create new VPS</a> | <a href="logout.php">Logout</a>

        <div class="vps">

            <?php

            $vps_instances = scandir($vps_dir);

            foreach ($vps_instances as $vps_name) {

                if ($vps_name !== '.' && $vps_name !== '..') {

                    $section_id = 'section_' . $vps_name;

                    echo "<h2>VPS: $vps_name 

                        <span class='toggle' onclick=\"toggleSection('$section_id')\">▶</span>

                    </h2>";

                    echo "<div id='$section_id' class='files'>";

                    echo "<h3>SSH Terminal</h3>";

                    echo "<div class='ssh'>

                        <div class='ssh-output' id='ssh-output-$vps_name'></div>

                        <div class='ssh-input'>

                            <input type='text' placeholder='Enter command (e.g., ls)' id='ssh-command-$vps_name'>

                            <button onclick=\"addSSHOutput('$vps_name', document.getElementById('ssh-command-$vps_name').value)\">Run</button>

                        </div>

                    </div>";

                    echo "<h3>File Manager</h3>";

                    echo "<ul>";

                    foreach (list_vps_files($vps_name, $vps_dir) as $file) {

                        echo "<li>$file 

                            <form method='POST' style='display:inline;'>

                                <input type='hidden' name='file_name' value='$file'>

                                <input type='hidden' name='vps_name' value='$vps_name'>

                                <button type='submit' name='delete_file'>Delete</button>

                            </form>

                            <a href='vps/$username/$vps_name/$file' download>Download</a>

                        </li>";

                    }

                    echo "</ul>";

                    echo "<form method='POST' enctype='multipart/form-data'>

                        <input type='hidden' name='vps_name' value='$vps_name'>

                        <input type='file' name='file'>

                        <button type='submit' name='upload'>Upload</button>

                    </form>";

                    echo "<form id='delete-vps-form-$vps_name' method='POST' style='display:inline;'>

                        <input type='hidden' name='vps_name' value='$vps_name'>

                        <button type='button' onclick=\"confirmDeletion('$vps_name')\" class='delete-confirm'>Delete VPS</button>

                    </form>";

                    echo "</div>";

                }

            }

            ?>

        </div>

    </div>

</body>

</html>