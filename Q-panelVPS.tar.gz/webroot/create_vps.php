
<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.html');
    exit;
}

$username = $_SESSION['user'];
$users_file = 'users.json';
$users = file_exists($users_file) ? json_decode(file_get_contents($users_file), true) : [];

if (!isset($users[$username])) {
    die('User not found. Contact admin.');
}

$max_ram = $users[$username]['max_ram'];
$max_storage = $users[$username]['max_storage'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vps_name = $_POST['vps_name'];
    $vps_dir = __DIR__ . "/vps/$username/$vps_name";

    if (!is_dir($vps_dir)) {
        mkdir($vps_dir, 0777, true);
        echo "VPS '$vps_name' created successfully with the following limits:<br>";
        echo "RAM: $max_ram GB<br>";
        echo "Storage: $max_storage GB<br>";
    } else {
        echo "VPS with this name already exists.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create VPS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="app">
        <h1>Create VPS</h1>
        <form action="create_vps.php" method="post">
            <input type="text" name="vps_name" placeholder="VPS Name" required>
            <button type="submit">Create VPS</button>
        </form>
        <p><a href="dashboard.php">Back to Dashboard</a></p>
    </div>
</body>
</html>
