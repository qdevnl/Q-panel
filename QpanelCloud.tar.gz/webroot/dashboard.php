<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];
$storage_dir = "storage/$username";

if (!file_exists($storage_dir)) {
    mkdir($storage_dir, 0777, true);
}

// Bestandsuploaden
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $upload_path = "$storage_dir/" . basename($file['name']);
    
    // Controleer of het een geldig bestand is
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        $message = "File uploaded succesfully";
    } else {
        $error = "Error.";
    }
}

// Bestand verwijderen
if (isset($_GET['delete'])) {
    $file_to_delete = "$storage_dir/" . $_GET['delete'];
    if (file_exists($file_to_delete)) {
        unlink($file_to_delete);
        $message = "File deleted.";
    } else {
        $error = "File not found.";
    }
}

// Lijst van bestanden in de opslagmap
$files = array_diff(scandir($storage_dir), ['.', '..']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Qpanel</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Dashboard</h1>
    <p>Welcome, <?php echo htmlspecialchars($username); ?>!</p>

    <?php if (isset($message)) echo "<p style='color: green;'>$message</p>"; ?>
    <?php if (isset($error)) echo "<p style='color: red;'>$error</p>"; ?>

    <h2>Files</h2>
    <ul>
        <?php foreach ($files as $file): ?>
            <li>
                <?php echo htmlspecialchars($file); ?>
                <a href="<?php echo "$storage_dir/$file"; ?>" download>Download</a>
                <a href="?delete=<?php echo urlencode($file); ?>">delete</a>
            </li>
        <?php endforeach; ?>
    </ul>

    <h2>Upload new file</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file" required>
        <button type="submit">Upload</button>
    </form>

    <a href="logout.php">Logout</a>
</body>
</html>

<?php
session_start();
$user = $_SESSION['username'] ?? null;

// JSON-bestand inladen
$data = json_decode(file_get_contents("users.json"), true);

// Controleer of gebruiker ingelogd is
if (!$user || !isset($data[$user])) {
    echo "user does not exist";
    exit;
}

// Haal opslaglimiet op
$storage_limit = $data[$user]['storage_limit_gb'] ?? 0;

// Bereken gebruikte opslagruimte
$user_dir = __DIR__ . "/uploads/$user"; // Pad naar de uploadmap van de gebruiker
$total_size = 0;

if (is_dir($user_dir)) {
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($user_dir));
    foreach ($files as $file) {
        if ($file->isFile()) {
            $total_size += $file->getSize();
        }
    }
}

// Omgerekend naar GB
$used_storage = round($total_size / (1024 ** 3), 2);

?>

<h2>Storage overview</h2>
<p><strong>Max storage:</strong> <?php echo $storage_limit; ?> GB</p>
<p><strong>Used storage:</strong> <?php echo $used_storage; ?> GB</p>
<p><strong>Useable storage:</strong> <?php echo max(0, $storage_limit - $used_storage); ?> GB</p>
