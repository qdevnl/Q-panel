<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['username'] ?? null;

    $password = $_POST['password'] ?? null;

    // Controleer of de gebruikersnaam en wachtwoord zijn ingevuld

    if (!$username || !$password) {

        echo "Username and password are needed for registering";

        exit;

    }

    // Laad bestaande gebruikersdata

    $data_file = 'users.json';

    if (!file_exists($data_file)) {

        $data = [];

    } else {

        $data = json_decode(file_get_contents($data_file), true);

    }

    // Controleer of gebruiker al bestaat

    if (isset($data[$username])) {

        echo "Username already exists";

        exit;

    }

    // Voeg nieuwe gebruiker toe met standaard opslaglimiet van 1GB

    $data[$username] = [

        'password' => $password,

        'role' => 'user',

        'storage_limit_gb' => 1 // Standaard 1GB opslaglimiet

    ];

    // Sla de nieuwe data op

    if (file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT))) {

        echo "Register succesfull.";

    } else {

        echo "Error.";

    }

}

?>

<!DOCTYPE html>

<html lang="nl">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register</title>

  <link rel="stylesheet" href="styles.css">

</head>

<body>

    <form action="register.php" method="POST">

        <h2>Register</h2>

        <label for="username">Username</label>

        <input type="text" id="username" name="username" required>

        <label for="password">Password</label>

        <input type="password" id="password" name="password" required>

        <button type="submit">Register</button>

    </form>

</body>

</html>